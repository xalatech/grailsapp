jQuery(document).ready(function(){
	
	jQuery('#klyngeVelger').change( function() {
		jQuery('#initialer').attr('value', '');
	});
		
});