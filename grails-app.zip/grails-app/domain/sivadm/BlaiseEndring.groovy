package sivadm

class BlaiseEndring {
	String instrumentId;
	String io_idnr;
	String primaryKeyValue;
	String mainSurveyId;
	String id_nr;
	String fornavn;
	String etternavn;
	String gateadresse;
	String bolignr;
	String postnr;
	String poststed;
	String kommune;
	String telefon1;
	String kildeTelefon1;
	String ikkeBruk1;
	String kommentarTelefon1;
	String telefon2;
	String kildeTelefon2;
	String kommentarTelefon2;
	String ikkeBruk2;
	String telefon3;
	String kildeTelefon3;
	String kommentarTelefon3;
	String ikkeBruk3;
	String epostadresse;
	String navn2;
	String fullForingsStatus;
	String kontaktInfoEndring;
}