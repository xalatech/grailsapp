package sivadm

class BlaiseFullForingsStatus {
	String instrumentId;
	String primaryKeyValue;
	String io_idnr;
	String fullForingsStatus;
}