package sivadm

class HistorieController {

    static scaffold = Historie
}
