package sivadm

class SkjemaInfoHendelseController {

    static scaffold = SkjemaInfoHendelse
}
